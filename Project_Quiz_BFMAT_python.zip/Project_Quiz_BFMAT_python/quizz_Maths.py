import os
from datetime import datetime

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def save_score(name, firstname, score, level, subject):
    with open("scores.txt", "a") as f:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        f.write(f"{timestamp} - {firstname} {name} - {subject} - Niveau {level} - Score: {score}\n")

def maths_quiz():
    clear_screen()
    print("=== QUIZ DE MATHÉMATIQUES ===")
    name = input("Entrez votre nom : ")
    firstname = input("Entrez votre prénom : ")
    
    levels = {
        "Facile": [
            ("Que vaut 7*8?", ["1. 46", "2. 56", "3. 54", "4. 57"], "2"),
            ("Quel est la formule du périmètre", ["1. (L+l)*2", "2. (L*l)/2", "3. S/L", "4. (L+l)*(L-l)"], "1"),
            ("L'unité de mesure du volume", ["1. l", "2. ml", "3. g", "4. hl"], "1"),
            ("Quel est le plus grand chiffre qui existe", ["1. 0", "2. 9", "3. 10", "4. infini"], "2"),
            ("A quoi est égal le bénéfice:", ["1. Perte+Prix de vente", "2. Reviens+Prix d'achat", "3. Prix de vente-Prix d'achat", "4. Prix d'achant-Perte"], "3")
        ],
        "Intermédiaire": [
            ("Quel est le factoriel de 5", ["1. 124", "2. 120", "3. 130", "4. 115"], "2"),
            ("La formule développée de (a-b)² est:", ["1. (a²-2ab+b²)", "2. (a-2ab+b²)", "3. (a²+2ab-b²)", "4. (b-2ab+a²)"], "1"),
            ("Que vaut la valeur de Pi?", ["1. 3.14", "2. 3.1417", "3. 3.15", "4. 4.14"], "1"),
            ("Quel est la valeur de l'angle nul", ["1. 0", "2. 180", "3. 360", "4. 400"], "1"),
            ("Que vaut sin2x:", ["1. (1-cos2x)/2", "2. (1+cos2x)/2", "3. (1+sin²x)/2", "4. 2sinxcosx"], "4")
        ],
        "Difficile": [
            ("Que vaut cos(2π/3)?", ["1. (-1/2)", "2. (1/2)", "3. 1", "4. 0"], "1"),
            ("Quelle est la dérivée de tan(x)?", ["1. 1+tan(x)", "2. (1/cosx)", "3. 1+tan²(x)", "4. (1/cos²(x))+1"], "3"),
            ("Quand est-ce que deux nombres sont premiers entre eux?", ["1. Quand ils ont 0 comme diviseur commun.", "2. Quand ils ont 1 comme diviseur commun.", "3. Quand ils ont 2 comme diviseur commun.", "4. Quand ils sont différents l'un de l'autre."], "2"),
            ("Qu'est-ce que le modulo?", ["1. reste de la division", "2. le quotient", "3. le reste de la division et le quotient", "4. le quotient-le diviseur"], "1"),
            ("Quand est-ce que des vecteurs sont coplanaires:", ["1. Quand l'un est égal à la somme des produits des autres par des scalaires", "2. Quand l'un est égal au produit des autres", "3. Quand tous les vecteurs sont identiques", "4. Quand la somme des vecteurs donne nombre impair"], "1")
        ]
    }
    
    clear_screen()
    print("\nChoisissez votre niveau de difficulté :")
    print("1. Facile")
    print("2. Intermédiaire")
    print("3. Difficile")
    
    while True:
        level_choice = input("Votre choix (1-3): ").strip()
        if level_choice in ["1", "2", "3"]:
            break
        print("Choix invalide. Veuillez entrer 1, 2 ou 3.")
    
    if level_choice == "1":
        questions = levels["Facile"]
        level_name = "Facile"
    elif level_choice == "2":
        questions = levels["Intermédiaire"]
        level_name = "Intermédiaire"
    else:
        questions = levels["Difficile"]
        level_name = "Difficile"
    
    score = 0
    
    clear_screen()
    print(f"\n=== NIVEAU {level_name.upper()} ===")
    
    for i, (question, answers, correct) in enumerate(questions, 1):
        print(f"\nQuestion {i}: {question}")
        for ans in answers:
            print(ans)
        
        while True:
            user_ans = input("Votre réponse (1-4): ").strip()
            if user_ans in ["1", "2", "3", "4"]:
                break
            print("Réponse invalide. Choisissez entre 1 et 4.")
        
        if user_ans == correct:
            print("Correct! +1 point")
            score += 1
        else:
            print(f"Incorrect. La bonne réponse était: {correct}")
    
    save_score(name, firstname, score, level_name, "Mathématiques")
    print(f"\nScore final: {score}/{len(questions)}")
    input("\nAppuyez sur Entrée pour retourner au menu...")

if __name__ == "__main__":
    maths_quiz()