import os
from datetime import datetime

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def save_score(name, firstname, score, level, subject):
    with open("scores.txt", "a") as f:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        f.write(f"{timestamp} - {firstname} {name} - {subject} - Niveau {level} - Score: {score}\n")

def english_quiz():
    clear_screen()
    print("=== ENGLISH QUIZ ===")
    name = input("Enter your name: ")
    firstname = input("Enter your firstname: ")
    
    levels = {
        "Facile": [
            ("What is the English word for: Eau ?", ["1. water", "2. wine", "3. juice"], "1"),
            ("How do you say Bonjour in English?", ["1. good night", "2. good morning", "3. goodbye"], "2"),
            ("What is the opposite of BIG?", ["1. thin", "2. Tall", "3. small"], "3"),
            ("What color is the sun?", ["1. Blue", "2. Yellow", "3. Green"], "2"),
            ("What is the capital of Burkina Faso?", ["1. Abidjan", "2. Ouagadougou", "3. Bobo-Dioulasso"], "2")
        ],
        "Intermédiaire": [
            ("Choose the correct sentence", ["1. she go to school", "2. she goes to school", "3. she going to school"], "2"),
            ("What time is it if the clock says 7:30?", ["1. Half past seven", "2. seven past thirty", "3. Thirty seven o'clock"], "1"),
            ("Translate \"Il aime jouer au football\"", ["1. He plays football.", "2. He likes playing football.", "3. He is play football."], "2"),
            ("What is the past tense of 'eat'?", ["1. Eated", "2. Ate", "3. Eaten"], "2"),
            ("'I have two brothers. ___ names are Paul and Simon.'", ["1. His", "2. Their", "3. Her"], "2")
        ],
        "Difficile": [
            ("Complete: 'If it rains, I ___ home.'", ["1. stay", "2. will stay", "3. stayed"], "2"),
            ("What does 'She is over the moon' mean?", ["1. She is very happy", "2. She is sleeping", "3. She is flying"], "1"),
            ("What is the English for 'Il a cassé la chaise par accident.'", ["1. He broke the chair by accident.", "2. He breaked the chair accidentally.", "3. He breaks the chair with accident."], "1"),
            ("'She has been studying English ___ three years.'", ["1. since", "2. for", "3. during"], "2"),
            ("Choose the correct form: 'This is the ___ book I've ever read!'", ["1. goodest", "2. better", "3. best"], "3")
        ]
    }
    
    total_score = 0
    
    for level_name, questions in levels.items():
        clear_screen()
        print(f"\n=== {level_name.upper()} LEVEL ===")
        level_score = 0
        
        for i, (question, answers, correct) in enumerate(questions, 1):
            print(f"\nQuestion {i}: {question}")
            for ans in answers:
                print(ans)
            
            while True:
                user_ans = input("Your answer (1-3): ").strip()
                if user_ans in ["1", "2", "3"]:
                    break
                print("Invalid answer. Choose between 1-3.")
            
            if user_ans == correct:
                print("Correct! +2 points")
                level_score += 2
            else:
                print(f"Wrong. The correct answer was: {correct}")
        
        total_score += level_score
        print(f"\n{level_name} level score: {level_score}/10")
        input("\nPress Enter to continue...")
    
    save_score(name, firstname, total_score, "All levels", "English")
    print(f"\nFinal score: {total_score}/30")
    input("\nPress Enter to return to menu...")

if __name__ == "__main__":
    english_quiz()