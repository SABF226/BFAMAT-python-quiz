import os
import subprocess
import sys

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def show_scores():
    clear_screen()
    if os.path.exists("scores.txt"):
        print("=== HISTORIQUE DES SCORES ===")
        with open("scores.txt", "r") as f:
            print(f.read())
    else:
        print("Aucun score enregistré pour le moment.")
    input("\nAppuyez sur Entrée pour continuer...")

def run_quiz(quiz_file):
    try:
        subprocess.run([sys.executable, quiz_file], check=True)
    except subprocess.CalledProcessError:
        print("\nUne erreur est survenue lors du lancement du quiz.")
        input("Appuyez sur Entrée pour continuer...")

def confirm_choice(quiz_name):
    clear_screen()
    print(f"Vous avez choisi : {quiz_name}")
    print("\nVoulez-vous :")
    print("1. Confirmer et lancer le quiz")
    print("2. Choisir un autre quiz")
    print("3. Retourner au menu principal")
    
    while True:
        choice = input("\nVotre choix (1-3) : ").strip()
        if choice in ["1", "2", "3"]:
            return choice
        print("Choix invalide. Veuillez entrer 1, 2 ou 3.")

def main_menu():
    quizzes = {
        "1": {"name": "Quiz d'Anglais", "file": "quizz_English.py"},
        "2": {"name": "Quiz de Culture Générale", "file": "quizz_general_knowledge.py"},
        "3": {"name": "Quiz de Mathématiques", "file": "quizz_Maths.py"},   
        "4": {"name": "Quiz de Français", "file": "quizz_French.py"},   
        "5": {"name": "Quiz de Biologie", "file": "quizz_Biology.py"},
    }

    while True:
        clear_screen()
        print("=== MENU PRINCIPAL ===")
        print("1. Quiz d'Anglais")
        print("2. Quiz de Culture Générale")
        print("3. Quiz de Mathématiques")
        print("4. Quiz de Français ")
        print("5. Quiz de Biologie")
        print("6. Voir les scores")
        print("7. Quitter")
        
        choice = input("\nVotre choix : ").strip()
        
        if choice in quizzes:
            quiz_info = quizzes[choice]
            confirmation = confirm_choice(quiz_info["name"])
            
            if confirmation == "1":
                run_quiz(quiz_info["file"])
            elif confirmation == "2":
                continue  # Retour au choix de quiz
            # Si confirmation == "3", on retourne au menu principal
            
        elif choice == "6":
            show_scores()
        elif choice == "7":
            print("\nMerci d'avoir joué ! À bientôt !")
            break
        else:
            input("\nChoix invalide. Appuyez sur Entrée pour continuer...")

if __name__ == "__main__":
    main_menu()