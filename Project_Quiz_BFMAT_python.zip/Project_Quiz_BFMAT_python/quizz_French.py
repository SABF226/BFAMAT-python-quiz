import os
import random
import time
from datetime import datetime

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def save_score(name, firstname, score, level, subject):
    with open("scores.txt", "a") as f:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        f.write(f"{timestamp} - {firstname} {name} - {subject} - Niveau {level} - Score: {score}\n")

def get_user_choice(valid_options):
    while True:
        choice = input("Votre choix : ").strip()
        if choice in valid_options:
            return choice
        print(f"Erreur : choisissez parmi {', '.join(valid_options)}")

def french_quiz():
    clear_screen()
    print("=== QUIZ DE FRANÇAIS ===")
    name = input("Entrez votre nom : ")
    firstname = input("Entrez votre prénom : ")
    
    levels = {
        "1": {
            "name": "FACILE",
            "questions": [
                ("Quel auteur a écrit 'Les Misérables' ?", ["1. Victor Hugo", "2. Gustave Flaubert", "3. Émile Zola"], "1"),
                ("Pluriel de 'cheval' :", ["1. chevaux", "2. chevals", "3. chevales"], "1"),
                ("Conjugaison de 'prendre' à la 1ère personne du pluriel (présent) :", ["1. prenons", "2. prenez", "3. prendons"], "1"),
                ("Mot correctement orthographié :", ["1. apprentissage", "2. aprentisage", "3. aprantissage"], "1"),
                ("Genre de 'armoire' :", ["1. féminin", "2. masculin", "3. neutre"], "1")
            ]
        },
        "2": {
            "name": "INTERMÉDIAIRE",
            "questions": [
                ("Temps verbal dans 'Il faut que tu viennes' :", ["1. subjonctif", "2. indicatif", "3. conditionnel"], "1"),
                ("Synonyme de 'péroraison' :", ["1. conclusion", "2. introduction", "3. argument"], "1"),
                ("Auteur de 'Madame Bovary' :", ["1. Flaubert", "2. Balzac", "3. Zola"], "1"),
                ("Nombre de voyelles en français :", ["1. 16", "2. 12", "3. 6"], "1"),
                ("Fonction grammaticale du sujet :", ["1. effectue l'action", "2. subit l'action", "3. complète l'action"], "1")
            ]
        },
        "3": {
            "name": "DIFFICILE",
            "questions": [
                ("Auteur de 'À la recherche du temps perdu' :", ["1. Proust", "2. Camus", "3. Sartre"], "1"),
                ("Accord du participe passé dans 'les lettres écrites' :", ["1. accord avec sujet", "2. accord avec COD", "3. invariable"], "2"),
                ("Figure de style dans 'Le soleil noir de la mélancolie' :", ["1. oxymore", "2. métaphore", "3. antiphrase"], "1"),
                ("Siècle des Lumières :", ["1. XVIIIe", "2. XVIIe", "3. XIXe"], "1"),
                ("Nombre de vers dans un sonnet français :", ["1. 14", "2. 12", "3. 16"], "1")
            ]
        }
    }
    
    clear_screen()
    print("\nChoisissez votre niveau de difficulté :")
    print("1. Facile (5 questions)")
    print("2. Intermédiaire (5 questions)")
    print("3. Difficile (5 questions)")
    level_choice = get_user_choice(["1", "2", "3"])
    
    questions = levels[level_choice]["questions"]
    level_name = levels[level_choice]["name"]
    max_score = len(questions) * 2
    
    score = 0
    lives = 3
    start_time = time.time()
    
    clear_screen()
    print(f"\n=== NIVEAU {level_name} ===")
    
    for i, (question, answers, correct) in enumerate(questions, 1):
        print(f"\nQuestion {i}/{len(questions)} (Vies restantes: {lives})")
        print(question)
        for ans in answers:
            print(ans)
        
        user_choice = get_user_choice(["1", "2", "3"])
        
        if user_choice == correct:
            score += 2
            print("Bonne réponse ! +2 points")
        else:
            lives -= 1
            print(f"Mauvaise réponse... La bonne réponse était {correct}")
            if lives <= 0:
                print("\nPlus de vies restantes !")
                break
    
    time_elapsed = round(time.time() - start_time)
    minutes, seconds = divmod(time_elapsed, 60)
    
    save_score(name, firstname, score, level_name, "Français")
    
    print(f"\nTemps écoulé : {minutes}min{seconds}sec")
    print(f"Score final : {score}/{max_score}")
    input("\nAppuyez sur Entrée pour retourner au menu...")

if __name__ == "__main__":
    french_quiz()