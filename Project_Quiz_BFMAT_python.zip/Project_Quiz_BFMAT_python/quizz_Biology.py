import os
from datetime import datetime

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def save_score(name, firstname, score, level, subject):
    with open("scores.txt", "a") as f:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        f.write(f"{timestamp} - {firstname} {name} - {subject} - Niveau {level} - Score: {score}\n")

def biology_quiz():
    clear_screen()
    print("=== QUIZ DE BIOLOGIE ===")
    name = input("Entrez votre nom : ")
    firstname = input("Entrez votre prénom : ")
    
    score = 0
    levels = ["Facile", "Intermédiaire", "Difficile"]
    
    for level in levels:
        clear_screen()
        print(f"\n=== NIVEAU {level.upper()} ===")
        
        if level == "Facile":
            questions = [
                ("Le corps humain comprend combien de parties:", ["1. deux parties", "2. trois parties", "3. cinq parties", "4. une partie"], "2"),
                ("Quelle est la couleur de la chlorophylle:", ["1. rouge", "2. bleue", "3. vert", "4. jaune"], "3"),
                ("Quel gaz les plantes libèrent-elles pendant la photosynthèse?:", ["1. oxygène", "2. dioxyde de carbone", "3. azote", "4. méthane"], "1")
            ]
        elif level == "Intermédiaire":
            questions = [
                ("Quel est le terme scientifique des globules rouges?:", ["1. leucocytes", "2. erythrocyte", "3. plaquettes", "4. lymphocytes"], "2"),
                ("Quelle partie de la cellule produit de l'énergie:", ["1. noyau", "2. mitochondrie", "3. ribosomes", "4. appareil de golgi"], "2"),
                ("Quel est le rôle principal des ribosomes dans une cellule:", ["1. produire de l'énergie", "2. synthétiser des protéines", "3. stocker l'ADN", "4. transporter des nutriments"], "2")
            ]
        else:
            questions = [
                ("Quelle est la longueur moyenne de l'ADN dans une cellule?:", ["1. 1mètre", "2. 2mètres", "3. 10centimètres", "4. 5mètres"], "2"),
                ("Quelle molécule est produite lors de l'information génétique:", ["1. ARN", "2. ADN", "3. protéine", "4. glucide"], "2"),
                ("Où se déroule la respiration cellulaire:", ["1. noyau", "2. cytoplasme", "3. mitochondrie", "4. réticulum endoplasmique"], "3")
            ]
        
        for i, (question, answers, correct) in enumerate(questions, 1):
            print(f"\nQuestion {i}: {question}")
            for ans in answers:
                print(ans)
            
            while True:
                user_ans = input("Votre réponse (1-4): ").strip()
                if user_ans in ["1", "2", "3", "4"]:
                    break
                print("Réponse invalide. Choisissez entre 1 et 4.")
            
            if user_ans == correct:
                print("Correct! +1 point")
                score += 1
            else:
                print(f"Incorrect. La bonne réponse était: {correct}")
    
    save_score(name, firstname, score, "Tous niveaux", "Biologie")
    print(f"\nScore final: {score}/9")
    input("\nAppuyez sur Entrée pour retourner au menu...")

if __name__ == "__main__":
    biology_quiz()