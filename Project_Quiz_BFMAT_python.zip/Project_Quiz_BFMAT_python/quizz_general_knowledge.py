import os
from datetime import datetime

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def save_score(name, firstname, score, level, subject):
    with open("scores.txt", "a") as f:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        f.write(f"{timestamp} - {firstname} {name} - {subject} - Niveau {level} - Score: {score}\n")

def general_knowledge_quiz():
    clear_screen()
    print("=== QUIZ DE CULTURE GÉNÉRALE ===")
    name = input("Entrez votre nom : ")
    firstname = input("Entrez votre prénom : ")
    
    levels = {
        "Facile": [
            ("Quelle est la capitale du Burkina Faso ?", ["1. Ouagadougou", "2. Bobo-Dioulasso", "3. Bamako", "4. Lomé"], "1"),
            ("Quel est le surnom du Burkina Faso ?", ["1. Pays des hommes intègres", "2. Pays du soleil levant", "3. Pays du Nil", "4. Pays des mille collines"], "1"),
            ("Quel est le principal fleuve qui traverse le Burkina Faso ?", ["1. Volta Noire", "2. Sénégal", "3. Niger", "4. Congo"], "1"),
            ("Quelle est la monnaie utilisée au Burkina Faso ?", ["1. Franc CFA", "2. Euro", "3. Dollar", "4. Naira"], "1"),
            ("Combien de pays limitrophes entourent le Burkina Faso ?", ["1. 4", "2. 5", "3. 6", "4. 16"], "3")
        ],
        "Intermédiaire": [
            ("Qui est le président qui a conduit le pays à l'indépendance ?", ["1. Thomas Sankara", "2. Maurice Yaméogo", "3. Blaise Compaoré", "4. Roch Kaboré"], "2"),
            ("Quel pays limitrophe du Burkina Faso n'est pas francophone ?", ["1. Togo", "2. Ghana", "3. Niger", "4. Mali"], "2"),
            ("À quel leader africain Ibrahim Traoré se réfère-t-il souvent dans ses discours ?", ["1. Nelson Mandela", "2. Kwame Nkrumah", "3. Patrice Lumumba", "4. Thomas Sankara"], "4"),
            ("Combien de régions administratives compte le Burkina Faso ?", ["1. 10", "2. 13", "3. 15", "4. 12"], "2"),
            ("Quelle est l'ethnie majoritaire au Burkina Faso ?", ["1. Mossi", "2. Bobo", "3. Dioula", "4. Peul"], "1")
        ],
        "Difficile": [
            ("Quel est le nom du Président qui a conduit le Burkina au Conseil de Sécurité de l'ONU comme membre non permanent ?", ["1. Thomas Sankara", "2. Blaise Compaoré", "3. Roch Kaboré", "4. Maurice Yaméogo"], "2"),
            ("Quelle est la superficie totale du Burkina Faso (environ) ?", ["1. 274 000 km2", "2. 322 000 km2", "3. 500 000 km2", "4. 150 000 km2"], "1"),
            ("Où se situe le Symposium international de sculpture sur granit ?", ["1. Laongo", "2. Bobo-Dioulasso", "3. Koudougou", "4. Dédougou"], "1"),
            ("Quel est le pourcentage approximatif de la population vivant en zone rurale ?", ["1. 50%", "2. 70%", "3. 80%", "4. 90%"], "3"),
            ("Quel est le nom du chef-lieu de la région du Sahel ?", ["1. Dori", "2. Ouagadougou", "3. Fada N'Gourma", "4. Gaoua"], "1")
        ]
    }
    
    clear_screen()
    print("\nChoisissez votre niveau de difficulté :")
    print("1. Facile")
    print("2. Intermédiaire")
    print("3. Difficile")
    
    while True:
        level_choice = input("Votre choix (1-3): ").strip()
        if level_choice in ["1", "2", "3"]:
            break
        print("Choix invalide. Veuillez entrer 1, 2 ou 3.")
    
    if level_choice == "1":
        questions = levels["Facile"]
        level_name = "Facile"
    elif level_choice == "2":
        questions = levels["Intermédiaire"]
        level_name = "Intermédiaire"
    else:
        questions = levels["Difficile"]
        level_name = "Difficile"
    
    score = 0
    
    clear_screen()
    print(f"\n=== NIVEAU {level_name.upper()} ===")
    
    for i, (question, answers, correct) in enumerate(questions, 1):
        print(f"\nQuestion {i}: {question}")
        for ans in answers:
            print(ans)
        
        while True:
            user_ans = input("Votre réponse (1-4): ").strip()
            if user_ans in ["1", "2", "3", "4"]:
                break
            print("Réponse invalide. Choisissez entre 1 et 4.")
        
        if user_ans == correct:
            print("Correct! +1 point")
            score += 1
        else:
            print(f"Incorrect. La bonne réponse était: {correct}")
    
    save_score(name, firstname, score, level_name, "Culture Générale")
    print(f"\nScore final: {score}/{len(questions)}")
    input("\nAppuyez sur Entrée pour retourner au menu...")

if __name__ == "__main__":
    general_knowledge_quiz()